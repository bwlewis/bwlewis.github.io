#' Stacked Area Plot Example Data
#'
#' Stacked Area Plot Example Data
#'
#' @docType data
#' @name stackedArea
#' @keywords datasets
#' @source
#' \url{http://nvd3.org/examples/stackedArea.html}.
#' @usage data(stackedArea)
#' @format A data frame.
#'
NULL
